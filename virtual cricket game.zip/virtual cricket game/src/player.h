#include<string>

class player {
public:
player();
std::string name;
int id;
int runsscored;
int ballsplayed;
int ballsbowled;
int runsgiven;
int wicketstaken;

};
