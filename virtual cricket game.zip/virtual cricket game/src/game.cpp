#include "game.h"
using namespace std;

game::game() {
	PlayersPerTeam =4;
	maxballs=6;
	totalplayers=11;

	players[0]="virat";
	players[1]="rohit";
	players[2]="dhawan";
	players[3]="pant";
	players[4]="karthik";
	players[5]="KL rahul";
	players[6]="jadeja";
	players[7]="hardik";
	players[8]="bumrah";
	players[9]="Bkumar";
	players[10]="ishant";

	 isfirstinnings=false;
	 teamA.name="team-A";
	 teamB.name="team-B";

}

void game::welcome(){
	cout<<"- - - - - - - - - - - - - - - - - - - - - - - - - - - -  - - - - - - - - - - - - - -  -"<<endl;
	cout<<"| - - - - - - - - - - - - - - - CRIC - IN - - - - - - - - - - - - - - - - - - - - |"<<endl;
	cout<<"|                                                                                                                   |"<<endl;
	cout<<"          WELCOME TO VIRTUEAL CRICKET GAME"<<endl;
	cout<<"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -- - - - -"<<endl;

	cout<<endl<<endl;
	cout<<"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ---  - - -"<<endl;
	cout<<"|= = = = = = = = = INSTRUCTIONS = = = = = = = = = = =| "<<endl;
	cout<<"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  - -  -"<<endl;
	cout<<"|                                                                                                 |"<<endl;
	cout<<"| 1.  create 2 teams (team-A and team - B with 4    |"<<endl;
	cout<<"|      players each) from a given pool of 11 players.  |"<<endl;
	cout<<"| 2.  lead the toss and decide the choice of play.      |"<<endl;
	cout<<"|  3.  each innings will be of 6 balls                               |"<<endl;
	cout<<"- - - - - - - - - - -- - - - - -- - - - - -- - - - - - - - - - - -- - - - -  - -"<<endl;
}
void game::showAllPlayers(){
	cout<<endl;
	cout<<"- - - - - - - - - - - -- - - - -- - - - - - - -- - - - - - -"<<endl;
	cout<<"= = = = = POOL OF PLAYERS = = = = = ="<<endl;
	cout<<"- - - - - - - - - - - - - --  -- - - - - - - -- - - - - - -- - "<<endl;

	for(int i=0;i<totalplayers;i ++){
		cout<<"\t\t["<<i<<"]"<<players[i]<<endl;
	}
}
	int game::takeIntegerInput() {
		int n;
		while(!(cin>>n)){
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(),'\n');
			cout<<"invalid input! please try again with valid input: ";
		}
		return n;
	}

	bool game::validateSelectedPlayer(int index){
		int n;
		vector<player>players;
		players=teamA.players;
		n=players.size();
		for(int i=0;i<n;i++){
			if (players[i].id==index){
				return false;
			}
		}
		players=teamA.players;
				n=players.size();
				for(int i=0;i<n;i++){
					if (players[i].id==index){
						return false;
					}
				}
					return true;
	}
void game::selectPlayers(){
	cout<<endl;
	cout<<"- - - - - - - - - - - - - - - - - - -- - - - - -"<<endl;
	cout<< "|= = = = = Create Team-A and Team-B= = = =| "<<endl;
	cout<<"- - - - - - - - - - - - - - - - - - - - - -- - - -"<<endl;
	for(int i =0;i<PlayersPerTeam;i++) {

		teamASelection:
		cout<<endl<<"select player "<<i+1<<" of team A- -";
		int playerIndexTeamA = takeIntegerInput();

		if(playerIndexTeamA<0||playerIndexTeamA>10){
			cout<<endl<<"please select from the given players"<<endl;
			goto teamASelection;
		} else if(!validateSelectedPlayer(playerIndexTeamA)) {
	           cout <<endl<< "Player already selected. Please choose another player." << endl;
	           goto teamASelection;
           }else{
		player teamAPlayer;
		teamAPlayer.id=playerIndexTeamA;
		teamAPlayer.name=players[playerIndexTeamA];
		teamA.players.push_back(teamAPlayer);
		}

		teamBSelection:
cout<<endl<<"select player "<<i+1<<" of team B- -";
		int playerIndexTeamB = takeIntegerInput();

		if(playerIndexTeamB<0||playerIndexTeamB>10){
					cout<<endl<<"please select from the given players"<<endl;
					goto teamBSelection;
				}else if (!validateSelectedPlayer(playerIndexTeamB))  {
				           cout << "Player already selected. Please choose another player." << endl;
				           goto teamBSelection;
	         } else{
		player teamBPlayer;
		teamBPlayer.id=playerIndexTeamB;
		teamBPlayer.name=players[playerIndexTeamB];
teamB.players.push_back(teamBPlayer);
				}
	}
}

void game::showTeamPlayers() {
	vector<player>teamAplayers=teamA.players;
	vector<player>teamBplayers=teamB.players;

	cout<<endl<<endl;
	cout<<"- - - - - - - - - - - - - - - - - - - - - - - - -- "<<endl;
	cout<<"|= = = = =Team-A= = == |\t\t|= = = =Team B= = = = = =|"<<endl;
	cout<<"- - - - - - - - - - - - -- - - - -- - - -- - - -- - -"<<endl;

	for(int i=0;i<PlayersPerTeam;i++){
		cout<<"|\t"<<"["<<i<<"]"<<teamAplayers[i].name<<"\t |"<<"\t\t";
		cout<<"|\t"<<"["<<i<<"]"<<teamBplayers[i].name<<"\t |"<<endl;
	}
	cout<<"- - - - - -- - - - -- - \t\t - - - - - -- - - - -- - - - -- - - -"<<endl<<endl;
}

void game::toss(){
	cout<<endl;
	cout<<"- - - - - - - - - - - - - - - - -  - - - - - - "<<endl;
	cout<<"|= = = = = Let's Toss = = = = = =|"<<endl;
	cout<<"- - - - - - - - - - - - - - - - - - - - - - - -"<<endl;
	cout<<"tossing the coin. . . .. "<<endl;
	srand(time(NULL));
	int randomvalue = rand()%2;
	switch(randomvalue){
	case 0:
		cout<<"team A won the toss"<<endl ;
		tossChoice (teamA);
		break;
	case 1:
	cout<<"teamB won the toss"<<endl;
	tossChoice(teamB);
	break;
	}
}

void game::tossChoice(team tosswinningteam) {
cout<<"enter 1 to bat or 2 to bowl first"<<endl<<"1.  bat"<<endl<<"2.  bowl"<<endl;
int tosschoice=takeIntegerInput();

cin.ignore(numeric_limits<streamsize>::max(),'\n');

switch(tosschoice){
case 1:
	cout<<endl<<tosswinningteam.name<<"won the toss and elected to bat first"<<endl<<endl;
	if(tosswinningteam.name.compare("Team-A")==0){
		battingteam=&teamA;
		bowlingteam=&teamB;
	} else{
		battingteam=&teamB;
		bowlingteam=&teamA;
	}
	break;
case 2:
	cout<<endl<<tosswinningteam.name<<"won the toss and choose to bowl first"<<endl<<endl;
	if(tosswinningteam.name.compare("Team-A")==0){
		bowlingteam	=&teamA;
		battingteam	=&teamB;
		} else{
			bowlingteam	=&teamB;
			battingteam=&teamA;
		}
	break;
default:
	cout<<endl<<"invalid input please try again: "<<endl<<endl;
	tossChoice(tosswinningteam);
	break;
}
}

void game::startFirstInnings(){
cout<<"\t\t ||| FIRST INNING STARTS |||"<<endl<<endl;
isfirstinnings=true;
initializePlayers();
playinnings();
}

void game::initializePlayers(){
batsman =&battingteam ->players[0];
bowler=&bowlingteam ->players[0];
cout<<battingteam->name<< " - "<<batsman->name<<"is batting"<<endl;
cout<<bowlingteam->name<<" - "<<bowler->name<<"is bowling"<<endl<<endl;

}

void game::playinnings(){
for(int i=0;i<maxballs;i++){
	cout<<"press enter to bowl...";
	getchar();
	cout<<"bowling..."<<endl;
	bat();

	if(!Validateinningsscore()){
		break;
	}
}
}

void game::bat(){
srand(time(NULL));
int runsScored=rand()%7;
batsman -> runsscored=batsman -> runsscored+runsScored;
battingteam->TotalRunsScored=battingteam->TotalRunsScored =runsScored;
batsman->ballsplayed=batsman->ballsplayed +1;

bowler->ballsplayed=bowler->ballsplayed+1;
bowlingteam->TotalBallsBowled=bowlingteam->TotalBallsBowled+1;
bowler->runsgiven=bowler->runsgiven +runsScored;

if(runsScored !=0){
	cout<<endl<<bowler->name<<"to"<<batsman->name<<" "<<runsScored<<"runs!"<<endl<<endl;
	showgamescorecard();
}else{
	cout<<endl<<bowler->name<<"to"<<batsman->name<<"OUT!"<<endl<<endl;

	battingteam->WicketsLost=battingteam->WicketsLost+1;
	bowler->wicketstaken=bowler->wicketstaken+1;

	showgamescorecard();

	int nextplayerindex = battingteam->WicketsLost;
	batsman =&battingteam->players[nextplayerindex];
}
}

bool game::Validateinningsscore(){
	if(isfirstinnings){
		if (battingteam->WicketsLost == PlayersPerTeam || bowlingteam->TotalBallsBowled == maxballs){
			cout<<"\t\t||| FIRST INNINGS ENDS |||"<<endl<<endl;
			cout<<battingteam->name<<" "<<battingteam->TotalRunsScored<<" --"<<battingteam->WicketsLost<<"("<<bowlingteam->TotalBallsBowled<<")"<<endl;
			cout<<bowlingteam->name<<"needs"<<battingteam->TotalRunsScored+1<<"runs to win the match"<<endl<<endl;
			return false;
		}
	} else {

	}
	return true;
}

void game::showgamescorecard(){
	cout<<"----------------------------------------------------------"<<endl;
	cout<<"\t"<<battingteam->name<<" "<<battingteam->TotalRunsScored<<" - "<<battingteam->WicketsLost
	<<"(" <<bowlingteam->TotalBallsBowled<<") | "<<batsman->name<<" "<<batsman->runsscored<<"("
	<<batsman->ballsplayed<<")\t"<<bowler->name<<" "<<bowler->ballsbowled<<"-"<<bowler->runsgiven
	<<"-"<<bowler->wicketstaken<<"\t"<<endl;
	cout<<"---------------------------------------------------------"<<endl;
}
void game::startSecondInnings(){
    cout << "\t\t||| SECOND INNING STARTS |||" << endl << endl;
    isfirstinnings = false;
    // Swap the batting and bowling teams
    team* temp = battingteam;
    battingteam = bowlingteam;
    bowlingteam = temp;
    
    // Initialize batsman and bowler for second innings
    batsman = &battingteam->players[0];
    bowler = &bowlingteam->players[0];
    cout << battingteam->name << " - " << batsman->name << " is batting" << endl;
    cout << bowlingteam->name << " - " << bowler->name << " is bowling" << endl << endl;
    
    playinnings();
}

void game::playinnings(){
    for(int i = 0; i < maxballs; i++){
        cout << "Press enter to bowl...";
        getchar();
        cout << "Bowling..." << endl;
        bat();
        
        if(!Validateinningsscore()){
            break;
        }
    }
}

bool game::Validateinningsscore(){
    if(isfirstinnings){
        if (battingteam->WicketsLost == PlayersPerTeam || bowlingteam->TotalBallsBowled == maxballs){
            cout << "\t\t||| FIRST INNINGS ENDS |||" << endl << endl;
            cout << battingteam->name << " " << battingteam->TotalRunsScored << " --" << battingteam->WicketsLost << "(" << bowlingteam->TotalBallsBowled << ")" << endl;
            cout << bowlingteam->name << " needs " << battingteam->TotalRunsScored + 1 << " runs to win the match" << endl << endl;
            startSecondInnings(); // Start second innings
            return false;
        }
    } else {
        if (battingteam->WicketsLost == PlayersPerTeam || bowlingteam->TotalBallsBowled == maxballs){
            cout << "\t\t||| SECOND INNINGS ENDS |||" << endl << endl;
            cout << battingteam->name << " " << battingteam->TotalRunsScored << " --" << battingteam->WicketsLost << "(" << bowlingteam->TotalBallsBowled << ")" << endl;
            displayMatchSummary(); // Display match summary
            return false;
        } else if (battingteam->TotalRunsScored > bowlingteam->TotalRunsScored){
            cout << "\t\t||| SECOND INNINGS ENDS |||" << endl << endl;
            cout << battingteam->name << " " << battingteam->TotalRunsScored << " --" << battingteam->WicketsLost << "(" << bowlingteam->TotalBallsBowled << ")" << endl;
            displayMatchSummary(); // Display match summary
            return false;
        }
    }
    return true;
}

void game::displayMatchSummary(){
    if(battingteam->TotalRunsScored > bowlingteam->TotalRunsScored){
        cout << battingteam->name << " wins the match by " << battingteam->TotalRunsScored - bowlingteam->TotalRunsScored << " runs" << endl;
    } else if (battingteam->TotalRunsScored < bowlingteam->TotalRunsScored){
        cout << bowlingteam->name << " wins the match by " << bowlingteam->TotalRunsScored - battingteam->TotalRunsScored << " runs" << endl;
    } else {
        cout << "It's a tie match" << endl;
    }
}