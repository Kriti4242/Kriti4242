#include "player.h"
using namespace std;

player::player() {
	runsscored =0;
	ballsplayed=0;
	ballsbowled =0 ;
	runsgiven =0;
	wicketstaken=0;
}
