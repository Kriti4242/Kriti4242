 #include "game.h"
#include<iostream>
using namespace std;

int main() {

game game;
game.welcome();

cout<<" \n press enter to continue";
getchar();

game.showAllPlayers();

cout<<" \n press enter to continue";
getchar();

game.selectPlayers();
game.showTeamPlayers();

cin.ignore(numeric_limits<streamsize>::max(),'\n');
cout<<" \n press enter to continue";
getchar();
game.toss();
game.startFirstInnings();

	return 0;
}
