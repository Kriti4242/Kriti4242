#include "team.h"
using namespace std;

team::team(){
	TotalRunsScored=0;
	WicketsLost=0;
	TotalBallsBowled=0;
}
