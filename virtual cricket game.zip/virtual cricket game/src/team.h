#include<vector>
#include "player.h"

class team {
public:
	team();
std::string name;
int TotalRunsScored;
int WicketsLost;
int TotalBallsBowled;
std::vector<player> players;


};
