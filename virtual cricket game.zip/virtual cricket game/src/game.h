#include <iostream>
#include <ctime>
#include <cstdlib>
#include <limits>
#include "team.h"

class game {
public:
game();
int PlayersPerTeam;
int maxballs;
int totalplayers;
std::string players[11];

bool isfirstinnings;
team teamA,teamB;
team *battingteam , *bowlingteam;
player *batsman, *bowler;

void welcome();
void showAllPlayers();
int takeIntegerInput();
void selectPlayers();
bool validateSelectedPlayer(int);
void showTeamPlayers();
void toss();
void tossChoice(team);
void startFirstInnings();
void initializePlayers();
void playinnings();
void bat();
bool Validateinningsscore();
void showgamescorecard();
void startSecondInnings();
void displayMatchSummary();
};
